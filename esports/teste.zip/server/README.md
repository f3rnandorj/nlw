# Back-end

## Entidade

### Game

id
title
bannerUrl

### AD

id
gameId
name
yarsPlaying
discord
weeksday
hourStart
hourEdn
useVoiceChannel
createdAt

## Casos de uso

- Listagem de games com contagem de anúncios
- Criação de novo anúncio
- Listagem de anúncios por game
- Buscar discord pelo ID do anúncio
